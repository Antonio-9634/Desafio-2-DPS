import { Alert } from 'react-native';

export const STORAGE_KEY = 'CITAS_TALLER';

export const isDuplicate = (citas, nuevaCita) => {
  return citas.some(
    cita =>
      cita.fecha === nuevaCita.fecha &&
      cita.vehiculo.toLowerCase() === nuevaCita.vehiculo.toLowerCase()
  );
};

export const parseDate = (input) => {
  const parsed = new Date(input);
  if (isNaN(parsed)) return null;
  return parsed;
};

export const validateAppointment = (nombre, vehiculo, fecha) => {
  if (nombre.trim().length < 3) {
    Alert.alert('Error', 'El nombre debe tener al menos 3 caracteres.');
    return false;
  }
  if (!vehiculo.trim() || !fecha.trim()) {
    Alert.alert('Error', 'Modelo del vehículo y la fecha son obligatorios.');
    return false;
  }
  const fechaIngresada = parseDate(fecha);
  if (!fechaIngresada || fechaIngresada <= new Date()) {
    Alert.alert('Error', 'La fecha debe tener un formato válido y ser futura.');
    return false;
  }
  return true;
};
