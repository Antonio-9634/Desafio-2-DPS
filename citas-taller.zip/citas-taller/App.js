import 'react-native-gesture-handler';
import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  FlatList,
  Alert,
  StyleSheet,
  TouchableOpacity,
  useWindowDimensions,
  StatusBar,
  KeyboardAvoidingView,
  Platform,
  ScrollView
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { NavigationContainer, useFocusEffect } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { Ionicons } from '@expo/vector-icons';

const Stack = createStackNavigator();

const STORAGE_KEY = 'CITAS_TALLER';

const COLORS = {
  background: '#121212',
  surface: '#1E1E1E',
  primary: '#BB86FC',
  primaryVariant: '#3700B3',
  secondary: '#03DAC6',
  error: '#CF6679',
  onBackground: '#FFFFFF',
  onSurface: '#E1E1E1',
  onPrimary: '#000000',
  onSecondary: '#000000',
};

const isDuplicate = (citas, nuevaCita) => {
  return citas.some(
    cita => cita.fecha === nuevaCita.fecha && cita.vehiculo.toLowerCase() === nuevaCita.vehiculo.toLowerCase()
  );
};

const HomeScreen = ({ navigation }) => {
  const [citas, setCitas] = useState([]);
  const { width } = useWindowDimensions();

  useFocusEffect(
    React.useCallback(() => {
      loadCitas();
    }, [])
  );

  const loadCitas = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) setCitas(JSON.parse(stored));
    } catch (error) {
      console.error('Error al cargar citas:', error);
    }
  };

  const eliminarCita = (id) => {
    Alert.alert('Confirmar', '¿Desea eliminar esta cita?', [
      { 
        text: 'Cancelar', 
        style: 'cancel',
      },
      {
        text: 'Eliminar',
        style: 'destructive',
        onPress: async () => {
          try {
            const nuevasCitas = citas.filter(c => c.id !== id);
            setCitas(nuevasCitas);
            await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nuevasCitas));
          } catch (error) {
            console.error('Error al eliminar cita:', error);
          }
        }
      }
    ]);
  };

  const columnas = width > 600 ? 2 : 1;

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
      
      <TouchableOpacity 
        style={styles.addButton}
        onPress={() => navigation.navigate('Agregar Cita')}
      >
        <Ionicons name="add" size={24} color={COLORS.onPrimary} />
        <Text style={styles.addButtonText}>Agregar Cita</Text>
      </TouchableOpacity>
      
      {citas.length === 0 ? (
        <View style={styles.emptyState}>
          <Ionicons name="calendar" size={48} color={COLORS.onSurface} />
          <Text style={styles.emptyStateText}>No hay citas programadas</Text>
          <Text style={styles.emptyStateSubText}>Presiona el botón para agregar una nueva cita</Text>
        </View>
      ) : (
        <FlatList
          data={citas}
          key={columnas}
          numColumns={columnas}
          keyExtractor={item => item.id.toString()}
          contentContainerStyle={styles.listContent}
          renderItem={({ item }) => (
            <View style={styles.card}>
              <Text style={styles.cardTitle}>{item.nombre}</Text>
              <View style={styles.cardRow}>
                <Ionicons name="car" size={16} color={COLORS.secondary} />
                <Text style={styles.cardText}>{item.vehiculo}</Text>
              </View>
              <View style={styles.cardRow}>
                <Ionicons name="time" size={16} color={COLORS.secondary} />
                <Text style={styles.cardText}>{item.fecha}</Text>
              </View>
              {item.descripcion && (
                <View style={styles.cardRow}>
                  <Ionicons name="document-text" size={16} color={COLORS.secondary} />
                  <Text style={styles.cardText} numberOfLines={2}>{item.descripcion}</Text>
                </View>
              )}
              
              <View style={styles.cardActions}>
                <TouchableOpacity 
                  style={[styles.actionButton, styles.editButton]}
                  onPress={() => navigation.navigate('Editar Cita', { cita: item })}
                >
                  <Ionicons name="create" size={16} color={COLORS.onPrimary} />
                  <Text style={styles.actionButtonText}>Editar</Text>
                </TouchableOpacity>
                
                <TouchableOpacity 
                  style={[styles.actionButton, styles.deleteButton]}
                  onPress={() => eliminarCita(item.id)}
                >
                  <Ionicons name="trash" size={16} color={COLORS.onPrimary} />
                  <Text style={styles.actionButtonText}>Eliminar</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}
        />
      )}
    </View>
  );
};

const AddAppointmentScreen = ({ navigation }) => {
  const [nombre, setNombre] = useState('');
  const [vehiculo, setVehiculo] = useState('');
  const [fecha, setFecha] = useState('');
  const [descripcion, setDescripcion] = useState('');

  const guardarCita = async () => {
    if (nombre.length < 3) {
      Alert.alert('Error', 'Nombre debe tener al menos 3 caracteres');
      return;
    }
    
    if (!vehiculo || !fecha) {
      Alert.alert('Error', 'Todos los campos excepto descripción son obligatorios');
      return;
    }
    
    const ahora = new Date();
    const fechaIngresada = new Date(fecha);
    if (fechaIngresada <= ahora) {
      Alert.alert('Error', 'La fecha debe ser futura');
      return;
    }

    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      const citas = stored ? JSON.parse(stored) : [];

      const nuevaCita = {
        id: Date.now(),
        nombre,
        vehiculo,
        fecha,
        descripcion,
      };

      if (isDuplicate(citas, nuevaCita)) {
        Alert.alert('Error', 'Ya existe una cita con la misma fecha y vehículo');
        return;
      }

      const nuevasCitas = [...citas, nuevaCita];
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(nuevasCitas));
      navigation.goBack();
    } catch (error) {
      console.error('Error al guardar cita:', error);
      Alert.alert('Error', 'No se pudo guardar la cita');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.formContainer}>
        <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
        
        <Text style={styles.formLabel}>Nombre del cliente</Text>
        <TextInput 
          placeholder="Juan Pérez" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={nombre} 
          onChangeText={setNombre} 
          style={styles.input} 
        />
        
        <Text style={styles.formLabel}>Modelo del vehículo</Text>
        <TextInput 
          placeholder="Toyota Corolla 2020" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={vehiculo} 
          onChangeText={setVehiculo} 
          style={styles.input} 
        />
        
        <Text style={styles.formLabel}>Fecha y hora</Text>
        <TextInput 
          placeholder="2025-05-25 14:30" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={fecha} 
          onChangeText={setFecha} 
          style={styles.input} 
        />
        
        <Text style={styles.formLabel}>Descripción del problema (opcional)</Text>
        <TextInput 
          placeholder="Ruido en el motor al acelerar" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={descripcion} 
          onChangeText={setDescripcion} 
          style={[styles.input, styles.multilineInput]} 
          multiline
          numberOfLines={3}
        />
        
        <TouchableOpacity 
          style={styles.saveButton}
          onPress={guardarCita}
        >
          <Text style={styles.saveButtonText}>Guardar Cita</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const EditAppointmentScreen = ({ route, navigation }) => {
  const { cita } = route.params;
  const [nombre, setNombre] = useState(cita.nombre);
  const [vehiculo, setVehiculo] = useState(cita.vehiculo);
  const [fecha, setFecha] = useState(cita.fecha);
  const [descripcion, setDescripcion] = useState(cita.descripcion);

  const actualizarCita = async () => {
    if (nombre.length < 3) {
      Alert.alert('Error', 'Nombre debe tener al menos 3 caracteres');
      return;
    }
    
    const ahora = new Date();
    const fechaIngresada = new Date(fecha);
    if (fechaIngresada <= ahora) {
      Alert.alert('Error', 'La fecha debe ser futura');
      return;
    }

    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      let citas = stored ? JSON.parse(stored) : [];

      citas = citas.map(c => c.id === cita.id ? { ...c, nombre, vehiculo, fecha, descripcion } : c);

      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(citas));
      navigation.goBack();
    } catch (error) {
      console.error('Error al actualizar cita:', error);
      Alert.alert('Error', 'No se pudo actualizar la cita');
    }
  };

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.formContainer}>
        <StatusBar barStyle="light-content" backgroundColor={COLORS.background} />
        
        <Text style={styles.formLabel}>Nombre del cliente</Text>
        <TextInput 
          placeholder="Juan Pérez" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={nombre} 
          onChangeText={setNombre} 
          style={styles.input} 
        />
        
        <Text style={styles.formLabel}>Modelo del vehículo</Text>
        <TextInput 
          placeholder="Toyota Corolla 2020" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={vehiculo} 
          onChangeText={setVehiculo} 
          style={styles.input} 
        />
        
        <Text style={styles.formLabel}>Fecha y hora</Text>
        <TextInput 
          placeholder="2025-08-25 14:30" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={fecha} 
          onChangeText={setFecha} 
          style={styles.input} 
        />
        
        <Text style={styles.formLabel}>Descripción del problema (opcional)</Text>
        <TextInput 
          placeholder="Ruido en el motor al acelerar" 
          placeholderTextColor={COLORS.onSurface + '80'} 
          value={descripcion} 
          onChangeText={setDescripcion} 
          style={[styles.input, styles.multilineInput]} 
          multiline
          numberOfLines={3}
        />
        
        <TouchableOpacity 
          style={styles.saveButton}
          onPress={actualizarCita}
        >
          <Text style={styles.saveButtonText}>Actualizar Cita</Text>
        </TouchableOpacity>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: COLORS.background,
    padding: 16,
  },
  formContainer: {
    paddingBottom: 20,
  },
  listContent: {
    paddingBottom: 20,
  },
  input: {
    backgroundColor: COLORS.surface,
    color: COLORS.onSurface,
    borderWidth: 1,
    borderColor: COLORS.surface,
    marginBottom: 16,
    padding: 14,
    borderRadius: 8,
    fontSize: 16,
  },
  multilineInput: {
    minHeight: 100,
    textAlignVertical: 'top',
  },
  formLabel: {
    color: COLORS.onSurface,
    fontSize: 14,
    marginBottom: 8,
    marginLeft: 4,
    opacity: 0.8,
  },
  card: {
    flex: 1,
    backgroundColor: COLORS.surface,
    margin: 8,
    padding: 16,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOpacity: 0.3,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 3,
    minWidth: 300,
  },
  cardTitle: {
    color: COLORS.onSurface,
    fontWeight: 'bold',
    fontSize: 18,
    marginBottom: 12,
  },
  cardText: {
    color: COLORS.onSurface,
    fontSize: 14,
    marginLeft: 8,
    opacity: 0.9,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  cardActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 16,
    borderTopWidth: 1,
    borderTopColor: COLORS.background + '40',
    paddingTop: 12,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 6,
  },
  actionButtonText: {
    marginLeft: 6,
    fontSize: 14,
    fontWeight: '500',
  },
  editButton: {
    backgroundColor: COLORS.primary,
  },
  deleteButton: {
    backgroundColor: COLORS.error,
  },
  addButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.primary,
    padding: 14,
    borderRadius: 8,
    marginBottom: 16,
  },
  addButtonText: {
    color: COLORS.onPrimary,
    fontSize: 16,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  saveButton: {
    backgroundColor: COLORS.primary,
    padding: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginTop: 8,
  },
  saveButtonText: {
    color: COLORS.onPrimary,
    fontSize: 16,
    fontWeight: 'bold',
  },
  emptyState: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 40,
  },
  emptyStateText: {
    color: COLORS.onSurface,
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    textAlign: 'center',
  },
  emptyStateSubText: {
    color: COLORS.onSurface + '80',
    fontSize: 14,
    marginTop: 8,
    textAlign: 'center',
  },
});

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        screenOptions={{
          headerStyle: {
            backgroundColor: COLORS.surface,
            shadowColor: 'transparent',
            elevation: 0,
          },
          headerTintColor: COLORS.onSurface,
          headerTitleStyle: {
            fontWeight: 'bold',
          },
          cardStyle: {
            backgroundColor: COLORS.background,
          },
        }}
      >
        <Stack.Screen 
          name="Inicio" 
          component={HomeScreen} 
          options={{ title: 'Citas Taller Mecánico' }}
        />
        <Stack.Screen 
          name="Agregar Cita" 
          component={AddAppointmentScreen} 
          options={{ title: 'Nueva Cita' }} 
        />
        <Stack.Screen 
          name="Editar Cita" 
          component={EditAppointmentScreen} 
          options={{ title: 'Editar Cita' }} 
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}